import { App } from './init';

var app = new App();

app.init();